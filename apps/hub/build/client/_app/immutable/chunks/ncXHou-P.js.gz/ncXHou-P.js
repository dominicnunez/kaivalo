import{b as p,E as t}from"./C6M8wlf6.js";import{B as c}from"./C9T96AC2.js";function E(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{E as s};
